﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Proyecto.Models;

namespace Proyecto.Controllers
{
    public class HomeController : Controller
    {
        //public INDEPENDENT_EMPLOYEE_DBEntities viejo = new INDEPENDENT_EMPLOYEE_DBEntities();
        public INDEPENDENT_EMPLOYEE_DBEntities2 db = new INDEPENDENT_EMPLOYEE_DBEntities2();
        public ActionResult Index()
        {

            ViewBag.IdCategoria = new SelectList(db.Categoria, "IdCategoria", "NombreCategoria");


            var model = new List<UsuarioModel>();

            return View(model);

        }

        [HttpPost]
        public async Task<ActionResult> Index(string idcategoria, string Lati, string Longt)
        {
            try
            {
                Lati = "9.9409802";
                Longt = "-84.1117706";
                var modelList = new List<Proyecto.Models.UsuarioModel>();
                ViewBag.IdCategoria = new SelectList(db.Categoria, "IdCategoria", "NombreCategoria");
                if (idcategoria != null && Lati != null && Longt != null)
                {
                    int id = Convert.ToInt32(idcategoria);

                    var result = db.CalculateDistance(Lati, Longt, id, 13).ToList();

                    
                    if (result.Count > 0)
                    {
                        foreach (var item in result)
                        {
                            var model = new UsuarioModel();

                            model.IdUsuario = item.IdUsuario;
                            model.Nombre = item.Nombre;
                            model.CedulaUsuario = item.CedulaUsuario;
                            model.Apellido1 = item.Apellido1;
                            model.Apellido2 = item.Apellido2;
                            model.Telefono1 = item.Telefono1;
                            model.Telefono2 = item.Telefono2;
                            model.ServicioAdomicilio = item.ServicioAdomicilio;
                            model.Edad = item.Edad;
                            model.Email = item.Email;
                            model.IdCita = item.IdCita;
                            model.Descripcion = item.Descripcion;
                            model.IdProvincia = item.IdProvincia;
                            model.IdCanton = model.IdCanton;
                            model.Detalle = item.Detalle;
                            model.IdDistrito = item.IdDistrito;
                            model.Longitud = item.Longitud;
                            model.Latitud = item.Latitud;

                            modelList.Add(model);
                        }
                    }

                    return View(modelList);
                }
                else
                {
                    ViewBag.Error = "Valide su posicion para obtener resultados cercanos";
                    return View(modelList);
                }
            }
            catch (Exception ex)
            {
                return View(ex);
                throw;
            }
        }


        public ActionResult Details(int otro)
        {
            try
            {
                var result = (from c in db.Usuario
                              where c.IdUsuario == otro
                              select c).FirstOrDefault();


                return View(result);
            }
            catch (Exception ex)
            {
                return View(ex);
                throw;
            }
        }

        public ActionResult Gridview()
        {
            var result = (from c in db.Usuario
                          select new GridUser
                          {
                              Nombre = c.Nombre,
                              Apellido1 = c.Apellido1,
                              Apellido2 = c.Apellido2,
                              IdCategoria = c.IdCategoria,
                              Telefono1 = c.Telefono1,
                              Edad = c.Edad,
                              Email = c.Email,
                              Descripcion = c.Descripcion,
                              Detalle = c.Detalle,
                              Longitud = c.Longitud,
                              Latitud = c.Latitud



                          });

            return View();
        }


        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

    }
}

