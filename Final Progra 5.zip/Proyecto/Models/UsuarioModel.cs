﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Web;

namespace Proyecto.Models
{
    public class UsuarioModel
    {
        public int IdUsuario { get; set; }
        [Display(Name = "Cedula:")]
        public int CedulaUsuario { get; set; }
        [Display(Name = "Nombre:")]
        public string Nombre { get; set; }
        [Display(Name = "Primer Apellido:")]
        public string Apellido1 { get; set; }
        [Display(Name = "Segundo Apellido:")]
        public string Apellido2 { get; set; }
        [Display(Name = "Profesíon:")]
        public int IdCategoria { get; set; }
        [Display(Name = "Telefono Personal:")]
        public int Telefono1 { get; set; }
        [Display(Name = "Telefono Secundario:")]
        public Nullable<int> Telefono2 { get; set; }
        [Display(Name = "Brinda Servicio Adomicilio:")]
        public Nullable<bool> ServicioAdomicilio { get; set; }
        [Display(Name = "Edad:")]
        public int Edad { get; set; }
        [Display(Name = "Correo Electronico:")]
        public string Email { get; set; }
        public Nullable<int> IdCita { get; set; }
        [Display(Name = "Descripcion Personal:")]
        public string Descripcion { get; set; }
        [Display(Name = "Provincia:")]
        public Nullable<int> IdProvincia { get; set; }
        [Display(Name = "Canton:")]
        public Nullable<int> IdCanton { get; set; }
        [Display(Name = "Detalle de las funciones que realiza:")]
        public string Detalle { get; set; }
        [Display(Name = "Distrito:")]
        public Nullable<int> IdDistrito { get; set; }
        public string Longitud { get; set; }
        public string Latitud { get; set; }


        public virtual Canton Canton { get; set; }
        public virtual Categoria Categoria { get; set; }
        public virtual Cita Cita { get; set; }
        public virtual Distrito Distrito { get; set; }
        public virtual Provincia Provincia { get; set; }
    }
}