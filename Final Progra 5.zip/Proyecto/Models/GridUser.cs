﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Proyecto.Models
{
    public class GridUser
    {

        public int IdUsuario { get; set; }
        public int CedulaUsuario { get; set; }
        public string Nombre { get; set; }
        public string Apellido1 { get; set; }
        public string Apellido2 { get; set; }
        public int IdCategoria { get; set; }
        public int Telefono1 { get; set; }
        public Nullable<int> Telefono2 { get; set; }
        public Nullable<bool> ServicioAdomicilio { get; set; }
        public Nullable<double> Calificacion { get; set; }
        public int Edad { get; set; }
        public string Email { get; set; }
        public Nullable<int> IdCita { get; set; }
        public string Descripcion { get; set; }
        public Nullable<int> IdProvincia { get; set; }
        public Nullable<int> IdCanton { get; set; }
        public string Detalle { get; set; }
        public Nullable<int> IdDistrito { get; set; }
        public string Longitud { get; set; }
        public string Latitud { get; set; }

        public virtual Canton Canton { get; set; }
        public virtual Categoria Categoria { get; set; }
        public virtual Cita Cita { get; set; }
        public virtual Distrito Distrito { get; set; }
        public virtual Provincia Provincia { get; set; }

    }
}